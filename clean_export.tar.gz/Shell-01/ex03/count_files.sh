find . | wc -l | tr -d '[:space:]' && echo "" 
